<template>
  <div class="contenedor">
  <h1>Juegos destacados</h1>

    <v-card width="600" v-for="item in local" :key="item.id" class="centrado">
        <v-img :src="item.img" :alt="item.alt">
        </v-img>

        <v-card-title primary-title>
          <div>
            <h2 class="headline mb-0">{{item.nombre}}</h2>
            <div>
              <p> {{item.detalle}} </p>
            </div>
          </div>
        </v-card-title>
      </v-card>

        
  </div>
</template>

<script>
  export default {
    name: 'HelloWorld',
  
    data: () => ({
      local:[],
    
     
    }),
    methods:{
      ver: function(){
        this.local=JSON.parse(localStorage.getItem("dato"))
      
       }

    },
      mounted:function(){
        this.ver();
  },

  }
</script>

<style>

h1{color:grey; width:100%; text-align:center}
.contenedor{width:100%;}
.centrado, .centrado > div{ margin:20px auto;}




</style>
