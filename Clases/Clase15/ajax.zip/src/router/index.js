import Vue from 'vue'
import VueRouter from 'vue-router'
import HomeView from '../views/HomeView.vue'


Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    name: 'Home',
    component: HomeView
  },
  {
    path: '/agregar',
    name: 'Ingresar',
    // route level code-splitting
    // this generates a separate chunk (ingresar.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "ingresar" */ '../views/IngresarView.vue')
  },
  {
    path: '/fav',
    name: 'Ver',
    // route level code-splitting
    // this generates a separate chunk (ver.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "ver" */ '../views/VerView.vue')
  }
]

const router = new VueRouter({
  routes
})

export default router
