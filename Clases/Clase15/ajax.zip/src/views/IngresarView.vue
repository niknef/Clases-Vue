<template>
  <div class="container">
    <h1>Ingresar</h1>
    <v-form
    ref="form">
    <v-text-field v-model="form_data.titulo" label="Titulo"  counter="10"></v-text-field>

    <v-textarea
          label="Comentario" v-model="form_data.comentario" rows="2"
          row-height="20"></v-textarea>
    
    <v-select
          :items ="items"
          label="Selecccionar"
            multiple v-model="form_data.selected">
    </v-select>

    <v-text-field v-model.number="form_data.estreno" label="Estreno"></v-text-field>
    <div class="i">
        <label for="imagen">Imagen del Juego</label>
    </div>
        <input type="file" id="imagen" @change="readFileInput">
          
          <div class="imagen-preview" v-if="form_data.imagen !== null">
                <img :src="form_data.imagen" alt="Preview de la imagen seleccionada">
          </div>

           <p class="er">{{error}}</p>
    <div class="guardar">        
    <v-btn
            color="primary"
            text
            @click="guardar(form_data)">
            Guardar
          </v-btn>
    </div>

    </v-form>
  </div>
</template>

<script>
export default {
  name:"IngresarView",

    data:function(){
    return {
      form_data:{
        titulo:"",
        comentario:"",
        selected:[],
         
        estreno:"",
        fecha:"",
        imagen:null
        },
    items:["Play1", "Play2", "Play3", "Play4", "Nintendo Switch", "XBox", "Otro"],
    arr:[],
    error:""
    }

  },

  methods:{

  readFileInput: function(ev) { //ev es el evento que desencadenó la función

            const file = ev.target.files[0]; //contiene un array con los archivos seleccionados. En este caso, se toma el primer archivo del array ([0]).
          
            if(file.size < 50000){ // si el tamaño del archivo es menor a 50000 bytes (50 KB). Si cumple esta condición no hay error
            this.error=""
                    
            const fr = new FileReader(); //Se crea una nueva instancia de FileReader llamada fr.
            fr.addEventListener('load', () => { //se agrega un event listener al evento 'load' de fr. Esto significa que cuando se complete la carga del archivo, se ejecutará la función callback asociada
                this.form_data.imagen = fr.result; //Dentro de la función callback, se asigna fr.result al atributo this.form_data.imagen. fr.result contiene los datos del archivo convertidos en una URL en formato de texto. 
            });
            fr.readAsDataURL(file);  // se llama al método readAsDataURL de fr, pasando el archivo como parámetro. Esto inicia el proceso de lectura del archivo y la conversión de sus datos en una URL.
          }
          else{ //Si el tamaño es mayor a 50KB, se asigna un mensaje de error al atributo this.error para indicar que el archivo debe pesar menos de 50 KB.
            this.error="Debe pesar menos de 50kb"
              }
         },

guardar:function(form_data){
  
form_data = Object.assign({}, form_data, { fecha: new Date().getTime() })
console.log(form_data)

    if(!localStorage.form){
      this.arr=[]
    }else{
      this.arr=JSON.parse(localStorage.getItem("form"))
      }

    this.arr.push(form_data)
  localStorage.setItem("form",JSON.stringify(this.arr))


this.$router.push('/fav');

}
},


}

</script>

<style>
.imagen-preview{
  margin:20px;
}
.i{margin:20px 0; 
  color:grey;
}
.guardar{
  margin:30px;

}
.er{
  color:red;
}

</style>