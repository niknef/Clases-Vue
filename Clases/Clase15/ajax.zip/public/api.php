<?php header("Access-Control-Allow-Origin: *");?>

[{
        "id": 1,
        "nombre" : "Super Mario 3D World",
        "detalle" : "Desarollado por Nintendo",
        "img": "sm.png",
        "alt": "Super Mario 3D World"
        
      },
{
        "id": 2,
        "nombre" : "Fortnite",
        "detalle" : "Desarrollado por la empresa Epic Games",
         "img": "fortnite.jpg",
        "alt": "Fortnite"

        },
{
        "id" : 3,
        "nombre" : "Spider- Man",
        "detalle" : "Acción y aventura basado, desarrollado por Insomniac Games y publicado por Sony Interactive Entertainment",
         "img": "spider.jpg",
        "alt": "Spider-Man"
        }
]