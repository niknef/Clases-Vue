<template>
  <div class="about">
      <div class="container">
  <div class="ver">
    <h1>Deseos Guardados</h1>
<transition-group tag="div" enter-active-class="animate__animated animate__backInRight">

 <div class="lista" v-for="item in local" :key="item.fecha">
    <p><span>Nombre: </span>{{item.titulo}} </p>
      <p><span>Comentario: </span>{{item.comentario}}</p> 
     <p><span>Consola: </span> 
      <span class="normal" v-for="x in item.selected" :key="x"> {{x}}  </span>, </p>
      <p><span>Estreno: </span>{{item.estreno}}</p>
      <img :src="item.imagen" :alt="item.nombre" />

     
        
</div>
</transition-group> 

    <p class="animate__animated animate__bounceIn animate__delay-2s animate__repeat-2">{{sin_datos}}</p>

  </div>
  </div>
  </div>
</template>

<script>
  export default{
      name: "VerView",

      data:function(){
      return {
        local:[],
        sin_datos: ""
      }
  },

    mounted:function(){
    console.log("se monto")
    this.ver_local();
  },

  
  methods:{
    ver_local:function(){
      
    if(localStorage.form){
    this.local=JSON.parse(localStorage.getItem("form")) 
        
      
    }
    if(this.local.length == 0){
      this.sin_datos ="Es hora de cargar datos !!"
    }
  
    }


  }
}

</script>
