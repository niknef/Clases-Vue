<template>
  <div>

  <section class="header">

      <h1>Productos</h1>

       <!-- Cart component -->
       
      <shop-carrito
          :cart="this.cart"
          :total="this.total"
          :nombre="dameNombre"
          @carrito-vacio="vaciarCarrito"
          @demodal="b">
      </shop-carrito>
      <p>{{aviso}}</p>


    </section>

   <v-data-iterator
      :items="items"
      :items-per-page.sync="itemsPerPage"
      :page.sync="page"
      :search="search"
      :sort-by="sortBy.toLowerCase()"
      :sort-desc="sortDesc"
      hide-default-footer
      no-results-text="Upa, no está lo que buscás">
      <template v-slot:header>
        <v-toolbar 
          dark
          color="blue darken-3"
          >
          <v-text-field
            v-model="search"
            clearable
            flat
            solo-inverted
            hide-details
            prepend-inner-icon="mdi-magnify"
            label="Buscar">
              
            </v-text-field>
          <template>
            <v-spacer></v-spacer>
            <v-select
              v-model="sortBy"
              flat
              solo-inverted
              hide-details
              :items="keys"
              prepend-inner-icon="mdi-magnify"
              label="Ordenar por"
            ></v-select>
            <v-spacer></v-spacer>
            <v-btn-toggle
              v-model="sortDesc"
              mandatory>
              <v-btn
                large
                depressed
                color="blue"
                :value="false">
                <v-icon>mdi-arrow-up</v-icon>
              </v-btn>
              <v-btn
                large
                depressed
                color="blue"
                :value="true">
                <v-icon>mdi-arrow-down</v-icon>
              </v-btn>
            </v-btn-toggle>
          </template>
        </v-toolbar>
      </template>

      <template v-slot:default="props">
        <v-row>
      
          <v-col class="column"
            v-for="item in props.items"
            :key="item.nombre">
            <v-card>
              <v-card-title class="subheading font-weight-bold">
                

          <!-- Item component -->
            <carrito-item
                 :item="item"
                 :key="item.id"
                 @actualizar-carrito="actualizar">
           </carrito-item>

         

              </v-card-title>

              <v-divider></v-divider>

              <v-list dense>
                <v-list-item
                  v-for="(key, index) in filteredKeys"
                  :key="index">
                  <v-list-item-content :class="{ 'blue--text': sortBy === key }">
                    {{ key }}:
                  </v-list-item-content>
                  <v-list-item-content
                    class="align-end"
                    :class="{ 'orange--text': sortBy === key }">
                    {{ item[key.toLowerCase()] }}
                 </v-list-item-content>
                </v-list-item>
              </v-list>

            </v-card>
          </v-col>
        </v-row>
      </template>

      <template v-slot:footer>
        <v-row
          class="mt-2"
          align="center"
          justify="center"
        >
          <span class="grey--text">Items por pagina</span>
          <v-menu offset-y>
            <template v-slot:activator="{ on, attrs }">
              <v-btn
                dark
                text
                color="primary"
                class="ml-2"
                v-bind="attrs"
                v-on="on">
                {{ itemsPerPage }}
                <v-icon>mdi-chevron-down</v-icon>
              </v-btn>
            </template>
            <v-list>
              <v-list-item
                v-for="(number, index) in itemsPerPageArray"
                :key="index"
                @click="updateItemsPerPage(number)">
                <v-list-item-title>{{ number }}</v-list-item-title>
              </v-list-item>
            </v-list>
          </v-menu>

          <v-spacer></v-spacer>

          <span
            class="mr-4
            grey--text">
            Página {{ page }} de {{ numberOfPages }}
          </span>
          <v-btn
            fab
            dark
            color="blue darken-3"
            class="mr-1"
            @click="formerPage">
            <v-icon>mdi-chevron-left</v-icon>
          </v-btn>
          <v-btn
            fab
            dark
            color="blue darken-3"
            class="ml-1"
            @click="nextPage"
          >
            <v-icon>mdi-chevron-right</v-icon>
          </v-btn>
        </v-row>
      </template>
    </v-data-iterator>
  

  </div>
</template>

<script>

import ShopCarrito from '../components/Shop-Carrito.vue';
import CarritoItem from '../components/Carrito-Item.vue';


import Fortnite from '../assets/fortnite.jpg';
import Sm from '../assets/sm.png';
import Spider from '../assets/spider.jpg';
import HorizonZeroDawn from '../assets/HorizonZeroDawn.jpg';
import Doom from '../assets/doom.jpg';
import MK11 from '../assets/mk11.jpg';

export default {
    name: 'HomeView',
    components: {
      ShopCarrito, CarritoItem
    },
    data() {
        return {

            cart: [],
            total: 0,
            nombre:[],
            aviso:"",

itemsPerPageArray: [4, 8, 12],
        search: '',
        filter: {},
        sortDesc: false,
        page: 1,
        itemsPerPage: 4,
        sortBy: 'nombre',
        keys: [
          'Nombre',
          'Precio',
          'Detalle',
          'Lanzamiento',
         ],
        items: [
          {
            id:1,
            nombre: 'Super Mario 3D World',
            imageSrc:Sm,
            detalle:"Adaptación mejorada de Super Mario 3D World, titulada Super Mario 3D World + Bowser's Fury, fue lanzada el 12 de febrero de 2021 para la consola Nintendo Switch.",
            precio:5000,
            lanzamiento:2021,
            alt:"Super Mario y compania"
          },
          {
            id:2,
            nombre: 'Fortnite',
            imageSrc:Fortnite,
            detalle:"Es un videojuego desarrollado por la empresa Epic Games, lanzado como diferentes paquetes de software que presentan diferentes modos de juego, pero que comparten el mismo motor de juego y mecánicas. Fue anunciado en los Spike Video Game Awards en 2011.",
            precio:5000,
            lanzamiento:2017,
            alt:"5 personajes en pose"
          },
          {
            id:3,
            nombre: 'Spider Man',
            imageSrc:Spider,
            detalle:"Marvel's Spider-Man es un videojuego de acción y aventura basado en el popular superhéroe hómonimo de la editorial Marvel Comics. Fue desarrollado por Insomniac Games y publicado por Sony Interactive Entertainment en exclusiva para la consola PlayStation 4. ",
            precio:1000,
            lanzamiento:2018,
            alt: "Gata Negra trepando con Spider-Man"
          },
          {
            id:4,
            nombre: 'Horizon Zero Dawn',
            imageSrc:HorizonZeroDawn,
            detalle:"Horizon Zero Dawn es un videojuego de acción, aventura y de mundo abierto desarrollado por Guerrilla Games y distribuido por Sony Interactive Entertainment para PlayStation 4.",
            precio:2000,
            lanzamiento:2017,
            alt:"Aloy con arco y flecha entre nubes"
          },
          {
            id:5,
            nombre: 'Doom Exodus',
            imageSrc:Doom,
            detalle: 'Doom es un videojuego de disparos en primera persona desarrollado por id Software y publicado por Bethesda Softworks. Es el cuarto título de la serie principal y la primera gran entrega desde Doom 3 en 2004. Se lanzó en todo el mundo en Microsoft Windows, PlayStation 4 y Xbox One el 13 de mayo de 2016 ',
            precio:500,
            lanzamiento:2016,
            alt:"Muchos monstruos peleando aparentemente en el infierno"
          },
            {
            id:6,
            nombre: 'MK 11',
            imageSrc:MK11,
            detalle: 'Videojuego de lucha desarrollado por NetherRealm Studios y publicado por Warner Bros. Interactive Entertainment. El juego se lanzó en Norteamérica y Europa el 23 de abril de 2019 para Microsoft Windows, Nintendo Switch, PlayStation 4 y Xbox One. ',
            precio:3000,
            lanzamiento:2019,
            alt:"Scorpion arrojando el Kunai"

          },
          
             
        ],
      

        }// cierre return
    },
    computed: {
      shoppingCartTotal() {
            return this.cart.map(item => item.precio).reduce((total, amount) => total + amount);
        },

      dameNombre(){
             return this.nombre.join(', ')
       },

      numberOfPages () {
        return Math.ceil(this.items.length / this.itemsPerPage)
      },
      filteredKeys () {
        return this.keys.filter(key => key !== 'Nombre')
      },
    


    },
    methods: {
        actualizar(e) {
            this.cart.push(e);
            console.log(e)
          
           this.nombre.push(e.nombre)
            console.log(this.nombre)
            this.total = this.shoppingCartTotal;
        },

        vaciarCarrito() {
          if(this.total > 0){
          var rta=confirm("Estas seguro de Vaciar el Carrito??")
          if (rta==true){
           this.b();
          }
        }
        },
         b() {
            this.cart = [];
            this.total = 0;
            this.nombre=[];
          
        },



      nextPage () {
        if (this.page + 1 <= this.numberOfPages) this.page += 1
      },
      formerPage () {
        if (this.page - 1 >= 1) this.page -= 1
      },
      updateItemsPerPage (number) {
        this.itemsPerPage = number
      },
    },

}
</script>

<style>

.header{
font: small-caps bold 1.2em Verdana;}






</style>