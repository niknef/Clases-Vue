<template>
  <div class="container">
    <h1>Lista de Deseos</h1>
    <v-form
    ref="form">
    <v-text-field v-model="form_data.titulo" label="Titulo"  counter="10"></v-text-field>

    <v-textarea
          label="Comentario" v-model="form_data.comentario" rows="2"
          row-height="20"></v-textarea>
    
    <v-select
          :items ="items"
          label="Selecccionar"
            multiple v-model="form_data.selected">
    </v-select>

    <v-text-field v-model.number="form_data.estreno" label="Estreno"></v-text-field>

   <div class="i">
        <label for="imagen">Imagen del Juego</label>
    </div>
        <input type="file" id="imagen" @change="readFileInput">
          
          <div class="imagen-preview" v-if="form_data.imagen !== null">
                <img :src="form_data.imagen" alt="Preview de la imagen seleccionada">
          </div>

           <p class="er">{{error}}</p>
    <div class="guardar">        
    <v-btn
            color="primary"
            text
            @click="guardar(form_data)">
            Guardar
          </v-btn>
    </div>

    </v-form>
  </div>
</template>

<script>
export default {
  name:"IngresarView",

    data:function(){
    return {
      form_data:{
        titulo:"",
        comentario:"",
        selected:[],
         
        estreno:"",
        fecha:"",
        imagen:null
        },
    items:["Play1", "Play2", "Play3", "Play4", "Ninendo Switch", "XBox", "Otro"],
    arr:[],
     error:""
    }

  },

  methods:{

  readFileInput: function(ev) {
            const file = ev.target.files[0];
          
            if(file.size < 50000){
            this.error=""
                    
            const fr = new FileReader();
            fr.addEventListener('load', () => {
                this.form_data.imagen = fr.result;
            });
            fr.readAsDataURL(file);
          }
          else{
            this.error="Debe pesar menos de 50kb"
              }
         },

  guardar:function(form_data){
  
form_data = Object.assign({}, form_data, { fecha: new Date().getTime() })
console.log(form_data)

    if(!localStorage.form){
      this.arr=[]
    }else{
      this.arr=JSON.parse(localStorage.getItem("form"))
      }

  this.arr.push(form_data)
  localStorage.setItem("form",JSON.stringify(this.arr))

this.$router.push('/fav');

}
},


}

</script>

<style>
.imagen-preview{
  margin:20px;
}
.i{margin:20px 0; 
  color:grey;
}
.guardar{
  margin:30px;

}
.er{
  color:red;
}

</style>