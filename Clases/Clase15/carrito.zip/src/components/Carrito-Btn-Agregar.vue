<template>
    <div>
    
       <v-btn depressed color="primary" @click="buttonClicked">Agregar
      </v-btn>
    
    
</div>
    
</template>

<script>

    export default {
        name: 'Carrito-Btn-Agregar',
        
       
        methods: {
            buttonClicked(e) {
                console.log(e)
                this.$emit('button-clicked')
            }
        }
    }
</script>

<style>

</style>
