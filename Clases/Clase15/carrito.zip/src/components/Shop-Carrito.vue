<template>
    <div class="carrito">
        <p>Cantidad: {{this.cart.length}} juegos</p>
        <p>Total: ${{this.total}}</p>
        <p v-if="this.nombre">Juegos : {{this.nombre}}</p>
        <p v-else>No hay juegos</p>
      
       
        <div class="comprar" v-show="this.cart.length > 0">
            <v-btn elevation="2" color="green lighten-2" @click="overlay = !overlay" class="bt">
                Comprar
            </v-btn>

             <carrito-btn-vacio @emit-carrito-vacio="emitirCarritoVacio" class="bt">
             </carrito-btn-vacio>  <!-- Button component -->
        <!--Recibe la señal/evento de emit-carrito-vacio y llamará a la función emitirCarritoVacio-->
            <v-overlay :value="overlay">
               <div v-if="this.cart.length > 0">
                    <div class="modal">
                        <p>Confirmar compra:</p>
                        <p>Juego/s: {{this.nombre}}</p>
                        <p>Cantidad de productos: {{this.cart.length}}</p>
                        <p>Abonar: {{this.total}}</p>
                        <div class="acciones">
                            <v-btn @click="demodal" color="green lighten-2" class="bt">ok</v-btn>
                            <v-btn color="red lighten-2" @click="overlay = false" class="bt">Cancelar</v-btn>
                        </div>
                    </div>
                </div>
                <div v-else>
                    <div class="modal">
                        <p>No hay productos</p>
                        <v-btn color="orange lighten-2" @click="overlay = false">
                            Cerrar
                        </v-btn>
                    </div>
                </div>
            </v-overlay>
        </div>
    </div>
</template>

<script>
import CarritoBtnVacio from './Carrito-Btn-Vacio.vue'

    export default {
        name: 'Shop-Carrito',
        components: {CarritoBtnVacio},
        props: ['cart', 'total', 'nombre'],
        data() {
            return {
                 overlay: false,
            }
        },
        methods: {
            emitirCarritoVacio() {
                this.$emit('carrito-vacio')
            },
              demodal() {
                this.overlay = false; // Para evitar que se muestre automaticamente
                this.$emit('demodal')
            }
        },

 
    }
</script>

<style>
.carrito{margin:20px; color: crimson;background: lightgray;width: 100%;margin-left: 0}
.carrito p{padding: 8px 30px;}
.modal{width: 500px;background: white;color: red;}
.modal p{padding:10px 20px;}
.comprar{display: inline-block; margin-left: 30px}
.acciones{margin: 0 auto;}
.acciones .bt, .comprar .bt{width:150px; display: inline-block;margin: 40px 0 50px 60px}
</style>
