<template>
     
         <v-btn color="error" elevation="2" @click="buttonClicked">Vaciar Carrito</v-btn>
</template>

<script>

    export default {
        name: 'Carrito-Btn-Vacio',

        methods: {
            buttonClicked() {
                this.$emit('emit-carrito-vacio')
            }
        }
    }
</script>

<style>

</style>
