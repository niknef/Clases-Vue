<template>
    <div class="center">
        <img :src="item.imageSrc" :alt="item.alt" class="ItemImage">
        <div class="item_detalle">
            <p>{{item.nombre}}</p>
    </div>
       


  <!-- componente boton -->

        <carrito-btn-agregar 
        @button-clicked="agregarAlCarrito(item)" :item="item">
        </carrito-btn-agregar>

     
    </div>
</template>

<script>
import CarritoBtnAgregar from './Carrito-Btn-Agregar.vue'

    export default {
        name: 'Carrito-Item',
        components: { CarritoBtnAgregar },
        props: ['item'],
       
        methods: {
            agregarAlCarrito(item) {
                console.log(item)
                this.$emit('actualizar-carrito', item)
            },

          
        }
    }
</script>

<style>

.item_detalle{
    font-weight:bold; 
    color:crimson; 
    font-size: 1.1em
}
.center{
    width:100%;
    text-align:center;
    border: solid 1px lightgray;

}

</style>
